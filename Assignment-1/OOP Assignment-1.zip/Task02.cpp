#include <iostream>
#include <cstdlib>
using namespace std;
class Table
{
    int TotalSeatsPerTable;
    int seatsOccupied;
    int FreeSeats;
    bool Clean;
    static int n;

public:
    Table()
    {
        this->TotalSeatsPerTable = 0;
        TotalSeatsPerTable = 4;
        seatsOccupied = 0;
        Clean = true;
        FreeSeats = 4;
    }
    Table(int _TotalSeatsPerTable)
    {
        if (abs(_TotalSeatsPerTable - 4) <= abs(_TotalSeatsPerTable - 8))
        {
            _TotalSeatsPerTable = 4;
        }
        else
        {
            _TotalSeatsPerTable = 8;
        }

        TotalSeatsPerTable = _TotalSeatsPerTable;
        FreeSeats = TotalSeatsPerTable;
        seatsOccupied = 0;
        Clean = true;
        cout << "Table: "<< n+1 << " has " << TotalSeatsPerTable << " seats" << endl;
        n++;
    }
    bool UsingTable(int n)
    {
        if (Clean && n <= TotalSeatsPerTable && seatsOccupied == 0)
        {
            seatsOccupied = n;
            return true;
        }
        return false;
    }
    void HavingLunch()
    {
        cout << "people are having lunch on this table" << endl;
        Clean = false;
    }
    void LeavingTable()
    {
        cout << "people are Laaving this table" << endl;
        seatsOccupied = 0;
        FreeSeats=TotalSeatsPerTable;
    }
    void CleaningTable()
    {
        cout << "Cleaning Table"<< endl;
        Clean = true;
    }
};
int Table:: n;
void OccupyTable(Table *t, int people, int tableNo)
{
    if(t[tableNo].UsingTable(people)){
        cout << "Table No: " << tableNo+1 << " has been occupied!"<< endl;
    }
}
void EmptyTable(Table* t, int tableNo){
    t[tableNo].LeavingTable();
    t[tableNo].CleaningTable();
    cout << "Table " << tableNo << " is emptied!" << endl;
}
int main()
{
    Table t[5] = {Table(4), Table(8), Table(8), Table(4), Table(4)};
    OccupyTable(t, 3, 0);
    t[1].HavingLunch();
    OccupyTable(t,3,1);
    EmptyTable(t,1);
    OccupyTable(t,6, 1);
}