#include <iostream>
using namespace std;
int Round(int c)
{
    while (c)
    {
        if (c % 2 == 0 || c % 3 == 0)
        {
            return c;
        }
        else
        {
            c++;
        }
    }
}
class RollerCoaster
{
    string name;
    double height;
    double length;
    double speed;
    int capacity;
    int CurrentNumRiders;
    bool RideInProgress;

public:
    RollerCoaster()
    {
        name = "rollercoaster";
        height = 500;
        length = 2000;
        speed = 0;
        capacity = 20;
        CurrentNumRiders = 0;
        RideInProgress = false;
    }
    RollerCoaster(string name, double height, double length, double speed, int capacity, int CurrentNumRiders)
    {
        if (capacity > 3)
        {
            capacity = Round(capacity);

            this->name = name;
            this->height = height;
            this->length = length;
            this->speed = speed;
            this->capacity = capacity;
            this->CurrentNumRiders = CurrentNumRiders;
            RideInProgress = false;
        }
    }
    void setName(string name)
    {
        this->name = name;
    }
    string getName()
    {
        return name;
    }
    void setHeight(double height)
    {
        this->height = height;
    }
    double getHeight()
    {
        return height;
    }
    void setLength(double lenght)
    {
        this->length = length;
    }
    double getLength()
    {
        return length;
    }
    void setSpeed(double speed)
    {
        this->speed = speed;
    }
    double getSpeed()
    {
        return speed;
    }
    void setCapacity(int capacity)
    {
        capacity = Round(capacity);
        this->capacity = capacity;
    }
    int getCapacity()
    {
        return capacity;
    }
    void setCurrentNumRiders(int CurrentNumRiders)
    {
        this->CurrentNumRiders = CurrentNumRiders;
    }
    int getCurrentNumRiders()
    {
        return CurrentNumRiders;
    }
    void setRideInProgress(bool RideInProgress)
    {
        this->RideInProgress = RideInProgress;
    }
    bool getRideInProgress()
    {
        return RideInProgress;
    }

    int LoadRiders()
    {
        if (RideInProgress == false)
        {
            if (CurrentNumRiders > capacity)
            {
                return CurrentNumRiders - capacity; // No of people that were not seated
            }
            else
                return 0;
        }
        return 0;
    }
    int StartRide()
    {
        if (RideInProgress == false)
        {
            RideInProgress = true;
            return CurrentNumRiders - capacity;
        }
        return -1;
    }
    void StopRide()
    {
        if (RideInProgress == true)
        {
            RideInProgress = false;
        }
    }
    void UnloadRiders()
    {
        if (RideInProgress == false)
        {
            CurrentNumRiders = 0;
            speed = 0;
        }
    }
    void AccelerateRollerCoaster()
    {
        speed += 3; // Roll No --> k23-0593
    }
    void Brakes()
    {
        speed -= 5;
    }
};
int main()
{
    RollerCoaster r1;
    RollerCoaster r2("sindbad", 200, 400, 20, 25, 30);

    cout << "Name " << r2.getName() << endl;
    cout << "height: " << r2.getHeight() << endl;
    cout << "Length: " << r2.getLength() << endl;
    cout << "Speed: " << r2.getSpeed() << endl;
    cout << "Capacity: " << r2.getCapacity() << endl;
    cout << "No of People: " << r2.getCurrentNumRiders() << endl;
    cout << "Status of Ride: " << r2.getRideInProgress() << endl
         << endl;
    cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=--=-=" << endl;
    cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=--=-=" << endl;
    if (r2.LoadRiders() > 0)
    {
        cout << "Riders have been seated!!!! No of people that were not seated: " << r2.LoadRiders() << endl;
    }
    else
    {
        cout << "All the riders were seated No empty seats available" << endl;
    }
    if (r2.StartRide() != -1)
    {
        cout << "Ride has been started " << endl;
    }
    else
    {
        cout << "Ride is already in progress " << endl;
    }
    cout << "Status of Ride: " << r2.getRideInProgress() << endl
         << endl;

    cout << "Increasing the speed: " << endl;
    r2.AccelerateRollerCoaster();
    cout << "New speed: " << r2.getSpeed() << endl;
    cout << "Increasing the speed: " << endl;
    r2.AccelerateRollerCoaster();
    cout << "New speed: " << r2.getSpeed() << endl;

    cout << "Decreasing the speed: " << endl;
    r2.Brakes();
    cout << "New speed: " << r2.getSpeed() << endl;

    r2.StopRide();
    cout << "Ride has been stopped!!!" << endl;
    cout << "Status of Ride: " << r2.getRideInProgress() << endl;
    r2.UnloadRiders();
    cout << "Empty seats: " << r2.getCurrentNumRiders() << endl;
    cout << "Speed: " << r2.getSpeed();
}