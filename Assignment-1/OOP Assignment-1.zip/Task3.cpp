#include <iostream>
#include <string>
using namespace std;
class ChessPiece
{
    string name;
    string color;
    char symbol;

public:
    ChessPiece()
    {
        name = "pawn";
        color = "white";
        symbol = 'p';
    }
    ChessPiece(string name, string color, char symbol)
    {
        this->name = name;
        this->color = color;
        this->symbol = symbol;
    }
    void setName(string name)
    {
        this->name = name;
    }
    string getName()
    {
        return name;
    }
    void setColor(string color)
    {
        this->color = color;
    }
    string getColor()
    {
        return color;
    }
    void setSymbol(char symbol)
    {
        this->symbol = symbol;
    }
    char getSymbol()
    {
        return symbol;
    }
};
class ChessBoard
{
private:
    ChessPiece Board[8][8];

public:
    ChessBoard()
    {
        for (int j = 0; j < 8; j++)
        {
            Board[6][j] = ChessPiece("pawn", "white", 'p');
        }
        for (int j = 0; j < 8; j++)
        {
            Board[1][j] = ChessPiece("pawn", "black", 'P');
        }
        for (int i = 2; i < 6; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                Board[i][j].setSymbol('-');
            }
        }
        Board[0][0] = ChessPiece("rook", "black", 'R');
        Board[0][1] = ChessPiece("knight", "black", 'N');
        Board[0][2] = ChessPiece("bishop", "black", 'B');
        Board[0][3] = ChessPiece("queen", "black", 'Q');
        Board[0][4] = ChessPiece("king", "black", 'K');
        Board[0][5] = ChessPiece("bishop", "black", 'B');
        Board[0][6] = ChessPiece("knight", "black", 'N');
        Board[0][7] = ChessPiece("rook", "black", 'R');

        Board[7][0] = ChessPiece("rook", "white", 'r');
        Board[7][1] = ChessPiece("knight", "white", 'n');
        Board[7][2] = ChessPiece("bishop", "white", 'b');
        Board[7][3] = ChessPiece("queen", "white", 'q');
        Board[7][4] = ChessPiece("king", "white", 'k');
        Board[7][5] = ChessPiece("bishop", "white", 'b');
        Board[7][6] = ChessPiece("knight", "white", 'n');
        Board[7][7] = ChessPiece("rook", "white", 'r');
    }
    void display()
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                cout << Board[i][j].getSymbol() << " ";
            }
            cout << endl;
        }
    }
    bool MovePiece(string source, string destination)
    {
        int xs, ys;
        int xd, yd;
        ys = (source.at(0) - 'a');
        yd = (destination.at(0) - 'a');
        xs = '8' - source.at(1);
        xd = '8' - destination.at(1);
                    // PAWN
        if (Board[xs][ys].getName() == "pawn" && Board[xs][ys].getSymbol() != '-' && ys == yd)
        {
            if (((xs + 1) == xd))
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 1][ys].setSymbol('p');
                    Board[xs][ys].setSymbol('-');
                }
                else if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs + 1][ys].setSymbol('P');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            else if ((xs + 2) == xd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 2][ys].setSymbol('p');
                    Board[xs][ys].setSymbol('-');
                }
                else if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs + 2][ys].setSymbol('P');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            else if ((xs - 1) == xd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs - 1][ys].setSymbol('p');
                    Board[xs][ys].setSymbol('-');
                }
                else if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs - 1][ys].setSymbol('P');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            else if ((xs - 2) == xd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs - 2][ys].setSymbol('p');
                    Board[xs][ys].setSymbol('-');
                }
                else if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs - 2][ys].setSymbol('P');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
        }
        // KNIGHT
        else if (Board[xs][ys].getName() == "knight" && Board[xs][ys].getSymbol() != '-')
        {
            if ((xs + 2) == xd && (ys + 1) == yd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 2][ys + 1].setSymbol('n');
                    Board[xs][ys].setSymbol('-');
                }
                if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs + 2][ys + 1].setSymbol('N');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
           else if ((xs + 2) == xd && (ys - 1) == yd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 2][ys + 1].setSymbol('n');
                    Board[xs][ys].setSymbol('-');
                }
                if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs + 2][ys + 1].setSymbol('N');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            else if ((xs + 1) == xd && (ys + 2) == yd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 1][ys + 2].setSymbol('n');
                    Board[xs][ys].setSymbol('-');
                }
                if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs + 1][ys + 2].setSymbol('N');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            else if ((xs + 1) == xd && (ys - 2) == yd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 1][ys + 2].setSymbol('n');
                    Board[xs][ys].setSymbol('-');
                }
                if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs + 1][ys + 2].setSymbol('N');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            
            else if ((xs -2 ) == xd && (ys + 1) == yd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 1][ys + 2].setSymbol('n');
                    Board[xs][ys].setSymbol('-');
                }
                if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs -2][ys + 1].setSymbol('N');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            else if ((xs +1) == xd && (ys-2) == yd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 1][ys + 2].setSymbol('n');
                    Board[xs][ys].setSymbol('-');
                }
                if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs -2][ys + 1].setSymbol('N');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            else if ((xs -1 ) == xd && (ys + 2) == yd)
            {
                if (Board[xs][ys].getColor() == "white")
                {
                    Board[xs + 1][ys + 2].setSymbol('n');
                    Board[xs][ys].setSymbol('-');
                }
                if (Board[xs][ys].getColor() == "black")
                {
                    Board[xs-1][ys + 2].setSymbol('N');
                    Board[xs][ys].setSymbol('-');
                }
                return true;
            }
            
        }
        return false;
    }
};
int main()
{

    ChessBoard c;
    c.display();
    cout << boolalpha << c.MovePiece("b2", "b4") << endl; // first move pawn
    c.display();
    cout << boolalpha << c.MovePiece("b8", "c6") << endl; // second move pawn
    c.display();
}