#include <iostream>
#include <string>
using namespace std;
class Pet
{
    string HealthStatus;
    int HungerLevel;
    int HapinessLevel;
    string SpecialSkills[2];

public:
    string species_name;
    void displayPetDetails()
    {
        cout << "Health status: " << HealthStatus << endl;
        cout << "Hunger Level: " << HungerLevel << endl;
        cout << "Happiness Level: " << HapinessLevel << endl;
        cout << "Special Skills: " << endl;
        for (int i = 0; i < 2; i++)
        {
            cout << i + 1 << ". " << SpecialSkills[i] << endl;
        }
    }
    void updateHapiness(int uHapiness)
    {
        HapinessLevel += uHapiness;
        if (HapinessLevel > 10)
        {
            HapinessLevel = 10;
        }
        else if (HapinessLevel < 0)
        {
            HapinessLevel = 0;
        }
    }
    void updateHealth(string uHealth)
    {
        HealthStatus = uHealth;
    }
    void updateHunger(int uHunger)
    {
        HungerLevel -= uHunger;
        if (HungerLevel > 10)
        {
            HungerLevel = 10;
        }
        else if (HungerLevel < 0)
        {
            HungerLevel = 0;
        }
        if (HungerLevel == 10)
        {
            updateHapiness(-1);
        }
        else if (HungerLevel == 0)
        {
            updateHapiness(1);
        }
    }
    Pet(){};
    Pet(string species_name, string HealthStatus, int HungerLevel, int HapinessLevel, string *SpecialSkills)
    {
        this->species_name = species_name;
        this->HealthStatus = HealthStatus;
        this->HungerLevel = HungerLevel;
        this->HapinessLevel = HapinessLevel;
        this->SpecialSkills[0] = SpecialSkills[0];
        this->SpecialSkills[1] = SpecialSkills[1];
    }
};
class Adopter
{
    string AdopterName;
    string AtopterMobileNo;
    Pet AdoptedPetRecords[2];

public:
    int count = 0;
    void adoptPet(Pet *p, string name)
    {
        int j = 0;
        for (int i = 0; i < 5; i++)
        {
            if (p[i].species_name == name)
            {
                AdoptedPetRecords[count] = p[i];
            }
        }
        count++;
    }
    void ReturnPet(Pet *p, string name)
    {
        for (int i = 0; i < 5; i++)
        {
            if (AdoptedPetRecords[i].species_name == name)
            {
                AdoptedPetRecords[i].species_name = "";
            }
        }
    }
    void display()
    {
        for (int i = 0; i < count; i++)
        {
            cout << "Adopted pet: " << i + 1 << endl;
            if (AdoptedPetRecords[i].species_name != "")
            {
                cout << "Name: " << AdoptedPetRecords[i].species_name << endl;
                AdoptedPetRecords[i].displayPetDetails();
            }
        }
    }
};
int main()
{
    string name;
    string uHealth;
    int uHapiness;
    int uHunger;
    string skills[2];
    Pet p[5];
    for (int i = 0; i < 5; i++)
    {
        cout << "Enter the details of pet: " << i + 1 << endl;
        cout << "Enter the Name: ";
        getline(cin, name);
        cout << "Enter the initial Health of the pet: ";
        getline(cin, uHealth);
        cout << "Enter the initial level of Happiness of the pet: ";
        cin >> uHapiness;
        cin.ignore();
        cout << "Enter the initial level of Hunger: ";
        cin >> uHunger;
        cin.ignore();
        cout << "Enter the first special skills: ";
        getline(cin, skills[0]);
        cout << "Enter the second special skill: ";
        getline(cin, skills[1]);

        p[i] = Pet(name, uHealth, uHapiness, uHunger, skills);
        cout << "----------------------------------------" << endl;
    }
    int choice = 0;
    int i = 0;

    while (choice != 5)
    {

        cout << "1. update Happiness Level: " << endl;
        cout << "2. update Hunger Level: " << endl;
        cout << "3. update Health status: " << endl;
        cout << "4. display: " << endl;
        cout << "5. Exit: " << endl;
        cout << "choose: " << endl;
        cin >> choice;
        cin.ignore();
        switch (choice)
        {
        case 1:
            cout << "Enter the level of happiness to increase (1-10): ";
            cin >> uHapiness;
            p[i].updateHapiness(uHapiness);
            break;
        case 2:
            cout << "Enter the amount to decrease the hunger(1-10): ";
            cin >> uHunger;
            p[i].updateHunger(uHunger);
            break;
        case 3:
            cout << "Enter the Health status: ";
            cin.ignore();
            getline(cin, uHealth);
            p[i].updateHealth(uHealth);
            break;
        case 4:
            for (int j = 0; j < 5; j++)
            {
                cout << "---------------------------" << endl;
                p[j].displayPetDetails();
            }
            break;
        }
        i++;
    }
    Adopter a;
    cout << "--------------------------------" << endl;
    for (int i = 0; i < 5; i++)
    {
        cout << p[i].species_name << endl;
    }
    cout << "--------------------------------" << endl;
    int c = -1;
    string adname;
    string retname;
    while (c != 0)
    {
        cout << "Press 1 to adopt, 2 to return a pet, or 0 to exit and display the adoption list: " << endl;
        cin >> c;
        cin.ignore();
        if (c)
        {
            cout << "Enter the pet name: ";
            getline(cin, adname);
            a.adoptPet(p, adname);
        }
        else if (c == 2)
        {
            cout << "Enter the pet name to return: ";
            getline(cin, retname);
            a.ReturnPet(p, retname);
        }
        else if (!c)
        {
            cout << endl
                 << endl;
            cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << endl;
            a.display();
        }
        else
        {
            cout << "Invalid info";
        }
    }
}